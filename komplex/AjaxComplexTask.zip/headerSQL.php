<?php
  $host = 'localhost';
  $db = 'users';
  $userDB = 'root';
?>